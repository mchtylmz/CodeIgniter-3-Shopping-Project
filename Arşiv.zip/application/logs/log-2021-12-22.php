<?php  ?>

ERROR - 2021-12-22 22:11:21 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:16:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:17:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:18:45 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:18:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:18:47 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:18:48 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:18:49 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:25:29 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:25:32 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:27:02 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:27:04 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:27:04 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:27:06 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 20:28:07 --> Severity: Warning --> Undefined variable $_SESSION /home/kotonkibriscom/public_html/application/config/config.php 560
ERROR - 2021-12-22 22:28:07 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 20:29:55 --> Severity: Warning --> Undefined variable $_SESSION /home/kotonkibriscom/public_html/application/config/config.php 560
ERROR - 2021-12-22 22:29:55 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 20:32:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/kotonkibriscom/public_html/application/config/config.php:575) /home/kotonkibriscom/public_html/system/core/Security.php 284
ERROR - 2021-12-22 22:32:27 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 20:33:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/kotonkibriscom/public_html/application/config/config.php:576) /home/kotonkibriscom/public_html/system/core/Security.php 284
ERROR - 2021-12-22 22:33:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:33:42 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:33:46 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:34:26 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 20:34:47 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /home/kotonkibriscom/public_html/application/config/config.php 599
ERROR - 2021-12-22 20:34:47 --> Severity: Warning --> foreach() argument must be of type array|object, bool given /home/kotonkibriscom/public_html/application/config/config.php 599
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:13 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:15 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:16 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:16 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:22 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:34 --> Cache: Failed to initialize APC; extension not loaded/enabled?
ERROR - 2021-12-22 22:35:56 --> Cache: Failed to initialize APC; extension not loaded/enabled?
