<?php

class Queue_controller extends Home_Core_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index($method)
    {
      if (method_exists($this, $method) == true) {
        return call_user_func_array([$this, $method], []);
      }
      throw new \Exception("Index Function Not Found", 404);
    }

    public function nebim($method)
    {
      if (method_exists($this, $method) == true) {
        return call_user_func_array([$this, $method], []);
      }
      throw new \Exception("Nebim Function Not Found", 404);
    }

    public function manuel($que_id)
    {
      $queue = $this->queue_model->get([
        'id' => clean_number($que_id), 'status <=' => '2'
      ]);
      if ($queue) {
        $update_data = [
          'attempt'   => $queue->attempt + 1,
          'status'    => 2,
          'worked_at' => date('Y-m-d H:i:s')
        ];
        // *****************
        try {
          if ($queue->method == 'user_id') {
            if ($user = get_user($queue->user_id)) {
              $reponse = nebim()->new_customer($user);
            } // if get_user
          } // if user_id
          if ($queue->method == 'order_id') {
            if ($order = get_order($queue->order_id)) {
              $reponse = nebim()->new_order($order);
            } // if get_order
          } // if order_id
          if (isset($reponse) && $reponse) {
            show_message('Sonuç :  ' . $reponse);
            $update_data['status'] = 3;
            $update_data['response'] = json_encode(['response' => $reponse]);
          } // if response
        } catch (\Exception $err) {
          show_message('Hata : ' . $err->getMessage());
          $update_data['failed_msg'] = json_encode(['error' => $err->getMessage()]);
        }
        // *****************
        if ($update_data['status'] == '2' && $queue->attempt >= 5) {
          $update_data['status'] = 4;
        }
        $this->queue_model->update_by_id($update_data, $queue->id);
      } // if queue
      echo 'Çalıştırıldı';
    }

    // Index Method
    public function user_id(int $limit = 10)
    {
      $this->process('user_id', function ($queue) {
        if ($user = get_user($queue->user_id)) {
          return nebim()->new_customer($user);
        } // if get_user
        return false;
      }, $limit);
    }

    // Index Method
    public function order_id(int $limit = 3)
    {
      $this->process('order_id', function ($queue) {
        if ($order = get_order($queue->order_id)) {
          return nebim()->new_order($order);
        } // if get_order
        return false;
      }, $limit);
    }

    // Nebim Method
    public function get_products()
    {
      echo json_encode(nebim()->get_products());
      exit;
      $this->db->truncate('nebim_getproducts');
      new_model('nebim_getproducts')->batchInsert(
        nebim()->get_products()
      );
      echo new_model('nebim_getproducts')->getLastInsertID() . ' ürün eklendi';
    }

    // Nebim Method
    public function update_products()
    {
      dd(
        nebim()->update_products()
      );
      $this->db->truncate('nebim_updateproducts');
      new_model('nebim_updateproducts')->batchInsert(
        nebim()->update_products(intval(input_get('min') ?? 5))
      );
      echo new_model('nebim_updateproducts')->getLastInsertID() . ' ürün eklendi';
    }

    // Nebim Method
    public function run_products($type = 'get')
    {
      $runTable = (input_get('type') == 'update' || $type == 'update') ? 'nebim_updateproducts':'nebim_getproducts';
      $nebimProducts = new_model($runTable)->findAll(['status' => 0], [
        'ModelKodu' => 'ASC', 'RenkAdi' => 'ASC', 'Beden' => 'ASC'
      ], 100);
      if ($nebimProducts) {
        foreach ($nebimProducts as $key => $nebimProduct) {
          show_message('Model Kodu : ' . $nebimProduct->ModelKodu);
          try {
            if ($runTable == 'nebim_updateproducts') {
              $this->run_update($nebimProduct);
            } else {
              $this->run_get($nebimProduct);
            }
            $nebimProduct_data = [
              'status' => 1
            ];
          } catch (\Exception $err) {
            show_message('Hata : ' . $err->getMessage());
            $nebimProduct_data = [
              'status'     => 2,
              'failed_msg' => $err->getMessage()
            ];
          } //  try
          $nebimProduct->update($nebimProduct_data, $nebimProduct->id);
        } // foreach $nebimProducts
      } // if $nebimProducts
    }

    /*
     * Private Functions
     */

    private function process($method, $calback, int $limit = 3)
    {
      $Queues = $this->queue_model->method($method, $limit);
      show_message(count($Queues) . ' kuyruk işlemi');
      foreach ($Queues as $key => $row) {
        $update_data = [
          'attempt'   => $row->attempt + 1,
          'status'    => 2,
          'worked_at' => date('Y-m-d H:i:s')
        ];
        // *****************
        try {
          if ($calback && $reponse = call_user_func($calback, $row)) {
            show_message('Sonuç :  ' . $reponse);
            $update_data['status'] = 3;
            $update_data['response'] = json_encode(['response' => $reponse]);
          }
        } catch (\Exception $err) {
          show_message('Hata : ' . $err->getMessage());
          $update_data['failed_msg'] = json_encode(['error' => $err->getMessage()]);
        }
        // *****************
        if ($update_data['status'] == '2' && $row->attempt >= 5) {
          $update_data['status'] = 4;
        }
        $this->queue_model->update_by_id($update_data, $row->id);
      } // foreach
    }

    private function run_get($nebimProduct, $addProduct = true)
    {
      product_queue_run_get($nebimProduct, $addProduct);
    }

    private function run_update($nebimProduct)
    {
      product_queue_run_get($nebimProduct, false);
    }
}
