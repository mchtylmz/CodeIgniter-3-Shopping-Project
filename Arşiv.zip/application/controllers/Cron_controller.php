<?php

class Cron_controller extends Home_Core_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Update Sitemap
     */
    public function update_sitemap()
    {
        $this->load->model('sitemap_model');
        $this->sitemap_model->update_sitemap();
    }

    /**
     * Clean Db
     */
    public function clean_db()
    {
      $before30day = date('Y-m-d H:i:s', strtotime('-30 days'));
      
      $this->db->where('created_at <', $before30day);
      if ($this->db->delete('nebim_log')) {
        echo 'import_log -> 30 gün öncesi silindi <br>';
      }

      $this->db->where('created_at <', $before30day);
      if ($this->db->delete('nebim_queue')) {
        echo 'import_log -> 30 gün öncesi silindi <br>';
      }
    }
}
